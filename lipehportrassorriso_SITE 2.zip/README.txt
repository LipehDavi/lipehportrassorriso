INSTRUÇÕES PARA PUBLICAR NO iPHONE:
1. NÃO abra o ZIP. Apenas baixe.
2. Acesse https://app.netlify.com no Safari.
3. Add new site → Deploy manually.
4. Toque para escolher arquivo.
5. Selecione este ZIP.
6. Pronto! O site estará online.

Nome ideal do site: lipehportrassorriso
